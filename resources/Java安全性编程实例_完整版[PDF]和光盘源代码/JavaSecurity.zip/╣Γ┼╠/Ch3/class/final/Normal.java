class Normal {
     MyDate d=new MyDate();
     public MyDate getMyDate(){
            return(d);
      }
}
