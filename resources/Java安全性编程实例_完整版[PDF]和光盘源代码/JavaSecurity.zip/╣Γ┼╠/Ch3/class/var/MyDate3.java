class MyDate3{
    public int year, month, day;
    public void setDay(int d){
        //���ֺϷ��Լ��
        //......
        day=d;
    }
    public int getDay( ){
        return(day);
    }
}
