class MyDate4{
    private int year, month, day;
    public void setDay(int d){
        //���ֺϷ��Լ��
        //......
        day=d;
    }
    public int getDay( ){
        return(day);
    }
}
